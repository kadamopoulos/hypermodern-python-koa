"""The hypermodern Python project of Konstantinos Adamopoulos."""

__version__ = "0.1.0"
